#!/usr/bin/env bash

#基礎安裝腳本(套件升級、安裝庫及安裝軟體開發工具)
yum update -y && yum install -y epel-release && yum groupinstall -y 'Development Tools'

#############################openssl安裝####################################

#自訂義版本
VERSION="1.1.1d"

#安裝包名稱
PACKAGE="openssl-$VERSION"

#下載目錄
SRCDIR="/opt/src"

#如果目錄不存在，就建立目錄
[ ! -d $SRCDIR ] && mkdir -p $SRCDIR

#進入安裝目錄
cd $SRCDIR

#下載官網編譯安裝包
curl -O -L "https://www.openssl.org/source/$PACKAGE.tar.gz"

#解壓縮編譯安裝包
tar -xzf "$PACKAGE.tar.gz"

#進入下載之編譯包目錄
cd $PACKAGE

#開始編譯安裝
./config
make
make install

#加載動態庫
echo "/usr/local/lib64" > /etc/ld.so.conf.d/openssl.conf
 
 
##############################安裝php7.1.32###################################
#安裝版本
VERSION="7.1.32"
#官網安裝包名稱
PACKAGE="php-$VERSION"
#下載目錄
SRCDIR="/opt/src"

#創建下載目錄
[ ! -d $SRCDIR ] && mkdir -p $SRCDIR

#進下載目錄並下載編譯安裝包
cd $SRCDIR
curl -O -L "https://www.php.net/distributions/$PACKAGE.tar.gz"
tar -xzf "$PACKAGE.tar.gz"
cd $PACKAGE

#安裝相依性套件
yum install -y epel-release && yum install -y libxml2-devel bzip2-devel curl-devel libwebp-devel libjpeg-devel libpng-devel libXpm-devel freetype-devel gmp-devel libicu-devel libmcrypt-devel postgresql-devel aspell-devel recode-devel libtidy-devel libxslt-devel ImageMagick-devel libmemcached-devel unixODBC-devel

#開始編譯安裝php
./configure  --prefix=/opt/php71 --with-config-file-path=/opt/php71/etc --with-config-file-scan-dir=/opt/php71/etc/php.d --with-zlib=/usr --enable-mbstring --enable-zip --enable-bcmath --enable-pcntl --enable-ftp --enable-exif --enable-calendar --enable-sysvmsg --enable-sysvsem --enable-sysvshm --enable-wddx --with-tidy --with-curl --with-mcrypt --with-iconv --with-gmp --with-pspell --with-gd --with-jpeg-dir=/usr --with-freetype-dir=/usr --with-png-dir=/usr --enable-gd-native-ttf --enable-gd-jis-conv --with-webp-dir=/usr --with-zlib-dir=/usr --with-xpm-dir=/usr --with-openssl --with-pdo-mysql=mysqlnd --with-gettext=/usr --with-bz2=/usr --with-recode=/usr --with-mysqli --enable-soap --enable-phar --with-xsl --with-xmlrpc --with-kerberos --enable-posix --enable-sockets --with-pcre-regex --with-libdir=lib64 --with-mysql-sock=/var/lib/mysql/mysql.sock --enable-shmop --enable-intl --with-icu-dir=/usr --with-pgsql=/usr/lib64/pgsql --with-pdo-pgsql --enable-fpm --enable-opcache
make
make install

#放置配置檔
cp -a /opt/php71/etc/php-fpm.conf.default /opt/php71/etc/php-fpm.conf
cp -a /opt/php71/etc/php-fpm.d/www.conf.default /opt/php71/etc/php-fpm.d/www.conf
cp -a php.ini-production /opt/php71/etc/php.ini
mkdir /opt/php71/etc/php.d

#修改配置檔




#配置curl官方 cacert來去使用pecl安裝其他軟件模組
curl -o /usr/local/ssl/cert.pem -L http://curl.haxx.se/ca/cacert.pem
echo "" | /opt/php71/bin/pecl install redis
echo "extension=redis.so" > /opt/php71/etc/php.d/redis.ini
echo "" | /opt/php71/bin/pecl install swoole
echo "extension=swoole.so" > /opt/php71/etc/php.d/swoole.ini
echo "" | /opt/php71/bin/pecl install apcu
echo "extension=apcu.so" > /opt/php71/etc/php.d/apce.ini
echo "" | /opt/php71/bin/pecl install imagick
echo "extension=imagick.so" > /opt/php71/etc/php.d/imagick.ini
echo "" | /opt/php71/bin/pecl install memcached
echo "extension=memcached.so" > /opt/php71/etc/php.d/memcached.ini
echo "" | /opt/php71/bin/pecl install mongodb
echo "extension=mongodb.so" > /opt/php71/etc/php.d/mongodb.ini
echo "zend_extension=opcache.so" > /opt/php71/etc/php.d/opcache.ini
echo "" | /opt/php71/bin/pecl install pdo_sqlsrv
echo "extension=pdo_sqlsrv.so" > /opt/php71/etc/php.d/pdo_sqlsrv.ini
echo "" | /opt/php71/bin/pecl install sqlsrv
echo "extension=sqlsrv.so" > /opt/php71/etc/php.d/sqlsrv.ini

#操作方式
echo "※※※※※※※※※※已安裝完成※※※※※※※※※※※"
echo "※※以下為模板列表："
/opt/php71/bin/php -m
echo "※※php-fpm 啟動方式："
echo "sudo /opt/php71/sbin/php-fpm"
