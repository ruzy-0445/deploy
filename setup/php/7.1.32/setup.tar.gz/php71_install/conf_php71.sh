#!/usr/bin/env bash
cp ./conf/php.ini /opt/php71/etc/
cp ./conf/php-fpm.conf /opt/php71/etc/
cp ./conf/www.conf /opt/php71/etc/php-fpm.d/
