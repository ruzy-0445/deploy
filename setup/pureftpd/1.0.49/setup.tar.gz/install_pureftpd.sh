#!/usr/bin/env bash

VERSION="1.0.49"
PACKAGE="pure-ftpd-$VERSION"

PATH="/usr/local/sbin:/usr/local/bin:"$PATH
SRCDIR="/opt/src"
DESTDIR="/opt/pureftpd"
CONFIG="$DESTDIR/etc/pure-ftpd.conf"
WORKDIR=$(pwd)
PORT="49921"
PASSIVEPORT="49900 49910"

function CreateSelfSignedCertificate() {
  cat << EOF > ssl.conf
[req]
prompt = no
default_md = sha256
default_bits = 2048
distinguished_name = dn

[dn]
C = TW
ST = Taiwan
L = Taipei
O = ITZXA Co.,Ltd.
OU = IT Department
CN = $(hostname)
EOF
  openssl req -x509 -new -nodes -sha256 -utf8 -days 3650 -newkey rsa:2048 -keyout "$1.key" -out "$1.crt" -config ssl.conf
  rm -f ssl.conf
}

if [ ! -d /usr/local/include/openssl ]; then
  if ! "$WORKDIR/install_openssl.sh"; then
    echo "install openssl fail!!!" && exit 2
  fi
  ldconfig
fi

yum install -y fortune-mod
yum groupinstall -y 'Development Tools'

[ ! -d $SRCDIR ] && mkdir -p $SRCDIR
cd $SRCDIR || exit 1
curl -O -L "https://download.pureftpd.org/pub/pure-ftpd/releases/$PACKAGE.tar.gz"
tar -xzf "$PACKAGE.tar.gz"
cd $PACKAGE || exit 1

./configure \
--prefix=$DESTDIR \
--localstatedir=$DESTDIR/var \
--sysconfdir=$DESTDIR/etc \
--with-certfile=$DESTDIR/etc/ssl/pure-ftpd.pem \
--with-keyfile=$DESTDIR/etc/ssl/pure-ftpd.pem \
--with-everything \
--with-paranoidmsg \
--with-virtualchroot \
--with-tls \
--without-inetd \
--with-boring \
--with-uploadscript

make
make install

mkdir -p $DESTDIR/var/{log,run}

[ ! -d $DESTDIR/etc/ssl ] && mkdir $DESTDIR/etc/ssl
if [ ! -f $DESTDIR/etc/ssl/pure-ftpd.pem ]; then
  cd $DESTDIR/etc/ssl || exit 1
  CreateSelfSignedCertificate "pure-ftpd"
  cat pure-ftpd.key pure-ftpd.crt > pure-ftpd.pem
  [ ! -d /etc/ssl/private ] && mkdir /etc/ssl/private
  openssl dhparam -out /etc/ssl/private/pure-ftpd-dhparams.pem 2048
fi

[ -f $DESTDIR/etc/pure-ftpd.conf ] && cp -a $DESTDIR/etc/pure-ftpd.conf $DESTDIR/etc/pure-ftpd.conf-orig

sed -i "s|VerboseLog                   no|VerboseLog                   yes|" $CONFIG
sed -i "s|NoAnonymous                  no|NoAnonymous                  yes|" $CONFIG
sed -i "s|# FortunesFile                 /usr/share/fortune/zippy|FortunesFile                 /usr/share/games/fortune/zippy|" $CONFIG
sed -i "s|# PureDB                       /etc/pureftpd.pdb|PureDB                       $DESTDIR/etc/pureftpd.pdb|" $CONFIG
sed -i "s|# PassivePortRange             30000 50000|PassivePortRange             $PASSIVEPORT|" $CONFIG
sed -i "s|# Bind                         127.0.0.1,21|Bind                         0.0.0.0,$PORT|" $CONFIG
sed -i "s|# AltLog                       clf:/var/log/pureftpd.log|AltLog                       clf:$DESTDIR/var/log/pureftpd.log|" $CONFIG
sed -i "s|# CreateHomeDir                yes|CreateHomeDir                yes|" $CONFIG
sed -i "s|# PIDFile                      /var/run/pure-ftpd.pid|PIDFile                      $DESTDIR/var/run/pure-ftpd.pid|" $CONFIG
sed -i "s|# TLS                          1|TLS                          3|" $CONFIG
sed -i "s|# TLSCipherSuite               HIGH|TLSCipherSuite               HIGH|" $CONFIG
sed -i "s|# IPV4Only                     yes|IPV4Only                     yes|" $CONFIG

sed -i 's/*.info;mail.none;authpriv.none;cron.none/*.info;mail.none;authpriv.none;cron.none;ftp.none/' /etc/rsyslog.conf
echo "" >> /etc/rsyslog.conf && echo "#PureFTP Custom Logging" >> /etc/rsyslog.conf && echo "ftp.* -/opt/pureftpd/var/log/pureftpd.log" >> /etc/rsyslog.conf
systemctl restart rsyslog

echo "### start pureftpd service ###"
echo "cd $DESTDIR && sbin/pure-ftpd etc/pure-ftpd.conf"
echo "### start pureftpd service ###"
echo "###########################"
echo "### stop pureftpd service ###"
echo "cd $DESTDIR && kill "'$(cat var/run/pure-ftpd.pid)'
echo "### stop pureftpd service ###"