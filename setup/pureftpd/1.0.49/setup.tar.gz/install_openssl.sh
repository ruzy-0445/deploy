#!/usr/bin/env bash

VERSION="1.1.1d"
PACKAGE="openssl-$VERSION"

SRCDIR="/opt/src"

yum groupinstall -y 'Development Tools'

[ ! -d $SRCDIR ] && mkdir -p $SRCDIR
cd $SRCDIR || exit 1
curl -O -L "https://www.openssl.org/source/$PACKAGE.tar.gz"
tar -xzf "$PACKAGE.tar.gz"
cd $PACKAGE || exit 1

./config
make
make install

echo "/usr/local/lib64" > /etc/ld.so.conf.d/openssl.conf