#!/bin/bash
#version:  v2

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

c_time=`date "+%F_%H:%M:%S"`
c_pwd=`pwd`

nginx_base_dir=/opt
[ -d ${nginx_base_dir} ] || mkdir ${nginx_base_dir}

##安裝依賴，創建nginx用户及編譯安裝所依賴的目錄
yum clean all
#yum -y update
yum -y install epel-release tree wget unzip
yum -y install gcc gcc-c++ make pcre pcre-devel zlib zlib-devel openssl openssl-devel net-tools perl git autoconf automake libtool
useradd -r -s /sbin/nologin -M www
mkdir -p ${nginx_base_dir}/src/nginx/
cp -r ${c_pwd}/conf ${c_pwd}/pkgs ${nginx_base_dir}/src/nginx/

## 安装gperftools
### libunwind-1.4.tar.gz -- gperftools的依赖 (wget -O libunwind.zip https://github.com/libunwind/libunwind/archive/b316234d63c7ff6fcfac6d72e0f27394fe86af80.zip or git clone https://github.com/libunwind/libunwind.git )
cd ${nginx_base_dir}/src/nginx/pkgs \
&& tar xf libunwind.tar.gz \
&& cd libunwind \
&& ./autogen.sh \
&& CFLAGS=-fPIC ./configure \
&& make CFLAGS=-fPIC \
&& make CFLAGS=-fPIC install
 
### 安装gperftools-2.7 與 安裝時使用的套件 (wget -O gperftools.zip https://github.com/gperftools/gperftools/archive/master.zip or git clone https://github.com/gperftools/gperftools.git)
cd ${nginx_base_dir}/src/nginx/pkgs \
&& yum -y install autoconf automake libtool \
&& tar xf gperftools.tar.gz \
&& cd gperftools \
&& ./autogen.sh \
&& ./configure && make && make install \
&& echo "/usr/local/lib" > /etc/ld.so.conf.d/usr_local_lib.conf \
&& ldconfig

## 安装新版openssl-1.1.1b (wget https://www.openssl.org/source/openssl-1.1.1d.tar.gz)
##openssl-1.0.2r之後的版本需要先安裝 perl 5
cd ${nginx_base_dir}/src/nginx/pkgs/nginx \
&& wget https://www.openssl.org/source/openssl-1.1.1d.tar.gz \
&& tar zxf openssl-1.1.1d.tar.gz && cd openssl-1.1.1d
#&& ./config && make && make install \
#&& mv /usr/bin/openssl /usr/bin/openssl.${c_time} && mv /usr/include/openssl /usr/include/openssl.${c_time} \
#&& ln -sv /usr/local/bin/openssl /usr/bin/openssl && ln -sv /usr/local/include/openssl /usr/include/openssl \
#&& echo "/usr/local/lib64" > /etc/ld.so.conf.d/openssl.conf && ldconfig


## 引入第三方模組並編譯安裝nginx
### nginx_upstream_check_module (wget -O /upstream_check.zip https://github.com/yaoweibin/nginx_upstream_check_module/archive/master.zip or git clone https://github.com/yaoweibin/nginx_upstream_check_module)需注意nginx对应的patch
### ngx_http_proxy_connect_module(wget -O proxy_connect.zip https://github.com/chobits/ngx_http_proxy_connect_module/archive/master.zip or git clone https://github.com/chobits/ngx_http_proxy_connect_module.git)需注意nginx对应的patch
### nginx-http-concat(wget -O http_concat https://github.com/alibaba/nginx-http-concat/archive/master.zip or git clone https://github.com/alibaba/nginx-http-concat.git)
### nginx-1.16.1.tar.gz (wget http://nginx.org/download/nginx-1.16.1.tar.gz)
### libmaxminddb (wget -O libmaxminddb https://github.com/maxmind/libmaxminddb/archive/85ff16afb2d547e1a74999e50667a4e493a3a13a.zip)
### nginx-module-vts (wget -O vts.zip https://github.com/vozlt/nginx-module-vts/archive/master.zip)
yum -y install patch httpd-tools \
&& cd ${nginx_base_dir}/src/nginx/pkgs/nginx/part3_modules \
&& cd libmaxminddb \
&& bash ./bootstrap && bash ./configure && make && make install \
&& sh -c "echo /usr/local/lib  >> /etc/ld.so.conf.d/local.conf" && ldconfig \
&& cd ${nginx_base_dir}/src/nginx/pkgs/nginx \
&& tar xf nginx-1.16.1.tar && cd nginx-1.16.1 \
&& patch -p1 < ../part3_modules/nginx_upstream_check_module/check_1.14.0+.patch \
&& patch -p1 < ../part3_modules/ngx_http_proxy_connect_module/patch/proxy_connect_rewrite_101504.patch \
&& ./configure --prefix=${nginx_base_dir}/nginx \
--sbin-path=${nginx_base_dir}/nginx/sbin/nginx \
--conf-path=${nginx_base_dir}/nginx/conf/nginx.conf \
--error-log-path=${nginx_base_dir}/nginx/logs/error.log  \
--http-log-path=${nginx_base_dir}/nginx/logs/access.log \
--pid-path=${nginx_base_dir}/nginx/pid/nginx.pid \
--lock-path=${nginx_base_dir}/nginx/lock/nginx.lock \
--modules-path=${nginx_base_dir}/nginx/modules \
--user=www \
--group=www \
--with-compat \
--with-file-aio \
--with-http_ssl_module \
--with-openssl=${nginx_base_dir}/src/nginx/pkgs/nginx/openssl-1.1.1d \
--with-http_v2_module \
--with-http_flv_module \
--with-http_mp4_module \
--with-http_gunzip_module \
--with-http_gzip_static_module \
--with-http_stub_status_module \
--with-http_random_index_module \
--with-http_realip_module \
--with-http_secure_link_module \
--with-http_slice_module \
--with-http_sub_module \
--with-stream_realip_module \
--with-stream_ssl_module \
--with-stream_ssl_preread_module \
--http-client-body-temp-path=${nginx_base_dir}/nginx/temp/client \
--http-proxy-temp-path=${nginx_base_dir}/nginx/temp/proxy \
--http-fastcgi-temp-path=${nginx_base_dir}/nginx/temp/fastcgi \
--http-uwsgi-temp-path=${nginx_base_dir}/nginx/temp/uwsgi \
--http-scgi-temp-path=${nginx_base_dir}/nginx/temp/scgi \
--with-google_perftools_module \
--with-pcre \
--with-stream \
--add-module=../part3_modules/nginx_upstream_check_module \
--add-module=../part3_modules/nginx-http-concat \
--add-module=../part3_modules/ngx_http_proxy_connect_module \
--add-module=../part3_modules/ngx_http_geoip2_module \
--add-module=../part3_modules/nginx-module-vts \
--with-threads && make && make install && mkdir -p ${nginx_base_dir}/nginx/temp/{proxy,client,fastcgi,uwsgi,scgi} && mkdir -p ${nginx_base_dir}/nginx/conf/{vhost,stream,conf.d,sslkeys} && mkdir -p ${nginx_base_dir}/nginx/geoip2

##準備配置文件及創建pid文件
cp -r ${c_pwd}/conf ${nginx_base_dir}/nginx/
touch ${nginx_base_dir}/nginx/pid/nginx.pid

##google-perftools添加線程目錄
mkdir ${nginx_base_dir}/nginx/temp/tcmalloc && chmod 0777 ${nginx_base_dir}/nginx/temp/tcmalloc

##下載Geoip2官方免費數據庫
wget -O ${nginx_base_dir}/src/nginx/geolite2-city.tar.gz https://geolite.maxmind.com/download/geoip/database/GeoLite2-City.tar.gz \
&& wget -O ${nginx_base_dir}/src/nginx/geolite2-country.tar.gz https://geolite.maxmind.com/download/geoip/database/GeoLite2-Country.tar.gz \
&& cd ${nginx_base_dir}/src/nginx \
&& tar zxf geolite2-city.tar.gz \
&& tar zxf geolite2-country.tar.gz \
&& mv ${nginx_base_dir}/src/nginx/GeoLite2-Country_*/GeoLite2-Country.mmdb ${nginx_base_dir}/nginx/geoip2/ \
&& mv ${nginx_base_dir}/src/nginx/GeoLite2-City_*/GeoLite2-City.mmdb ${nginx_base_dir}/nginx/geoip2/

# 寫入系統執行及執行路徑
# cat << EOF > /usr/lib/systemd/system/nginx.service
# [Unit]
# Description=nginx.service
# After=network.target
# [Service]
# Type=forking
# ExecStart=${nginx_base_dir}/nginx/sbin/nginx
# ExecReload=${nginx_base_dir}/nginx/sbin/nginx -s reload
# ExecStop=${nginx_base_dir}/nginx/sbin/nginx -s stop
# PrivateTmp=true
# [Install]
# WantedBy=multi-user.target
# EOF
# systemctl daemon-reload
# echo "export PATH=$PATH:${nginx_base_dir}/nginx/sbin" >> /etc/profile
# systemctl enable nginx
